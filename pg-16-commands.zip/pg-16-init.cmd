@ECHO ON

pushd %CD%

%~d0
cd %~dp0

call pg-16-vars.cmd

"%PGDIR%\bin\initdb" -U postgres -A trust -E UTF8

popd