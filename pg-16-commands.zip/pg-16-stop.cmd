@ECHO ON

pushd %CD%

%~d0
cd %~dp0

call pg-16-vars.cmd

"%PGDIR%\bin\pg_ctl" -D "%PGDATA%" -l "%PGLOGS%" stop

popd